//
//  ViewController.h
//  voucher_swap
//
//  Created by Brandon Azad on 12/7/18.
//  Copyright © 2018 Brandon Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *myButton;

@end

@interface FileManagerViewController : UIViewController


@end

@interface FileListTableView : UITableView

@end
