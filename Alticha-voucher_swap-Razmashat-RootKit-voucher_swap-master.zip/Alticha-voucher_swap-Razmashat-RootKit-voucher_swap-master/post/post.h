#ifndef post_h
#define post_h

#include <stdio.h>
#include <Foundation/Foundation.h>

@interface Post : NSObject

- (bool)go;
- (void)respring;

@end

#endif /* post_h */
