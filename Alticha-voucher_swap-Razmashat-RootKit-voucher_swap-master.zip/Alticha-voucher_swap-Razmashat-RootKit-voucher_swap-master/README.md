# A rewritten version in Swfit is currently in the works. I will update this page when it is finished.(02/03/19)

# Alticha-voucher_swap-Razmashat-RootKit-voucher_swap
This combines Alticha-voucher_swap + Razmashat-RootKit-voucher_swap to get a FileManager on A12

WARNING-- I did not modify the UI, and tried to keep the individual projects that I combined working as intended. 

Special thanks to everyone in the community pushing the jailbreak along!!

*Especially s/o to Alticha for getting the A12 working and Razmashat for the File Manager*

# voucher_swap
A fork of bazad's voucher_swap.
<br>
# Exploitation
Currently supports all 16K devices.
<br>
# Post Exploitation
Currently gets root and unsandboxes the application.
Also pushes use to a Razmashat's File Manager
# Credits
- bazad
<br>tfp0
- Alticha
<br>modifications and post exploitation
- Razmashat
<br>File Manager

*TESTED on 
<br>-iPhone XS Max iOS 12.1.2 (ver 2) (iPhone 11,6)
<br>-iPad6,3 iOS 12.1 (iPad Pro 9.7")
<br> TESTED BY tbiancostuff - iPhone 6s iOS 12.0

# Updates can also be found here for the project
https://www.reddit.com/r/jailbreak/comments/amccvj/discussion_ive_merged_altichavoucher_swap_with/
